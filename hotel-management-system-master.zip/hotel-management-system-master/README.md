# hotel-management-system
**Hotel management system is an Tkinter based(Python module) application that can be used by any hotel to :-**
 
-Reserve a room

-To get the status of room (i.e. available or reserved)

-To check the amenities available in the room

-To check the total number of guests in the hotel now

-To find the total number of available and reserved rooms

-To manage staff

-To find contacts of different authorities of hotel

-To find the payment information by providing the payment id

A filter is also provided which gives you the option to fill fields(amenities) according to the guest's choice and find the available rooms with the choosen amenities sorted in order from lowest price to highest price

## Requirements
```
python-3

```



